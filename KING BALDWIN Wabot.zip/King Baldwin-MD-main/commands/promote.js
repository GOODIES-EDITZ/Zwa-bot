const { isAdmin } = require('../lib/isAdmin');

/**
 * Promote users manually via command
 */
async function promoteCommand(sock, chatId, mentionedJids, message) {
    let targets = [];

    // Prioritize mentions
    if (mentionedJids?.length) {
        targets = mentionedJids;
    } 
    // Fallback to replied message
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        targets = [message.message.extendedTextMessage.contextInfo.participant];
    }

    if (!targets.length) {
        await sock.sendMessage(chatId, {
            text: '⚠️ You must mention someone or reply to their message to promote!'
        });
        return;
    }

    try {
        // Promote in group
        await sock.groupParticipantsUpdate(chatId, targets, 'promote');

        // Build fancy usernames for mentions
        const userTags = targets.map(jid => `🛡️ @${jid.split('@')[0]} 🛡️`);

        const botJid = sock.user.id;

        const promotionMsg = `
🏰 *『 KINGDOM PROMOTION 』* 🏰
━━━━━━━━━━━━━━━━━━━━━━

✨ *Promoted Hero${targets.length > 1 ? 'es' : ''}:* 
${userTags.join('\n')}

👑 *Promoted By:* @${botJid.split('@')[0]}

📜 *Date & Time:* ${new Date().toLocaleString()}

⚔️ Rise and serve the kingdom with honor! ⚔️
`;

        await sock.sendMessage(chatId, {
            text: promotionMsg,
            mentions: [...targets, botJid]
        });
    } catch (err) {
        console.error('Promotion command error:', err);
        await sock.sendMessage(chatId, { text: '❌ Failed to promote the hero(es)!' });
    }
}

/**
 * Handle automatic promotion events
 */
async function handlePromotionEvent(sock, groupId, participants, author) {
    try {
        if (!Array.isArray(participants) || !participants.length) return;

        const userTags = participants.map(jid => `🛡️ @${(typeof jid === 'string' ? jid : jid.id).split('@')[0]} 🛡️`);
        let mentionList = participants.map(jid => (typeof jid === 'string' ? jid : jid.id));

        let promotedBy = 'System';
        if (author) {
            const authorJid = typeof author === 'string' ? author : author.id;
            promotedBy = `@${authorJid.split('@')[0]}`;
            mentionList.push(authorJid);
        }

        const autoPromotionMsg = `
🏰 *『 KINGDOM PROMOTION 』* 🏰
━━━━━━━━━━━━━━━━━━━━━━

✨ *Promoted Hero${participants.length > 1 ? 'es' : ''}:*
${userTags.join('\n')}

👑 *Promoted By:* ${promotedBy}

📜 *Date & Time:* ${new Date().toLocaleString()}

⚔️ Serve the kingdom with valor! ⚔️
`;

        await sock.sendMessage(groupId, {
            text: autoPromotionMsg,
            mentions: mentionList
        });

    } catch (err) {
        console.error('Error handling promotion event:', err);
    }
}

module.exports = { promoteCommand, handlePromotionEvent };