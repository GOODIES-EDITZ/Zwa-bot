/*const { handleWelcome } = require('../lib/welcome');
const { isWelcomeOn, getWelcome } = require('../lib/index');
const { channelInfo } = require('../lib/messageConfig');
const fetch = require('node-fetch');

async function welcomeCommand(sock, chatId, message, match) {
    // Check if it's a group
    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { text: 'This command can only be used in groups.' });
        return;
    }

    // Extract match from message
    const text = message.message?.conversation || 
                message.message?.extendedTextMessage?.text || '';
    const matchText = text.split(' ').slice(1).join(' ');

    await handleWelcome(sock, chatId, message, matchText);
}

async function handleJoinEvent(sock, id, participants) {
    // Check if welcome is enabled for this group
    const isWelcomeEnabled = await isWelcomeOn(id);
    if (!isWelcomeEnabled) return;

    // Get custom welcome message
    const customMessage = await getWelcome(id);

    // Get group metadata
    const groupMetadata = await sock.groupMetadata(id);
    const groupName = groupMetadata.subject;
    const groupDesc = groupMetadata.desc || 'No description available';

    // Send welcome message for each new participant
    for (const participant of participants) {
        try {
            // Handle case where participant might be an object or not a string
            const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
            const user = participantString.split('@')[0];
            
            // Get user's display name
            let displayName = user; // Default to phone number
            try {
                const contact = await sock.getBusinessProfile(participantString);
                if (contact && contact.name) {
                    displayName = contact.name;
                } else {
                    // Try to get from group participants
                    const groupParticipants = groupMetadata.participants;
                    const userParticipant = groupParticipants.find(p => p.id === participantString);
                    if (userParticipant && userParticipant.name) {
                        displayName = userParticipant.name;
                    }
                }
            } catch (nameError) {
                console.log('Could not fetch display name, using phone number');
            }
            
            // Process custom message with variables
            let finalMessage;
            if (customMessage) {
                finalMessage = customMessage
                    .replace(/{user}/g, `@${displayName}`)
                    .replace(/{group}/g, groupName)
                    .replace(/{description}/g, groupDesc);
            } else {
                // Default message if no custom message is set
                const now = new Date();
                const timeString = now.toLocaleString('en-US', {
                    month: '2-digit',
                    day: '2-digit', 
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true
                });
                
                finalMessage = `╭╼━≪•𝙽𝙴𝚆 𝙼𝙴𝙼𝙱𝙴𝚁•≫━╾╮\n┃𝚆𝙴𝙻𝙲𝙾𝙼𝙴: @${displayName} 👋\n┃Member count: #${groupMetadata.participants.length}\n┃𝚃𝙸𝙼𝙴: ${timeString}⏰\n╰━━━━━━━━━━━━━━━╯\n\n*@${displayName}* Welcome to *${groupName}*! 🎉\n*Group 𝙳𝙴𝚂𝙲𝚁𝙸𝙿𝚃𝙸𝙾𝙽*\n${groupDesc}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ Knight Bot*`;
            }
            
            // Try to send with image first (always try images)
            try {
                // Get user profile picture
                let profilePicUrl = `https://img.pyrocdn.com/dbKUgahg.png`; // Default avatar
                try {
                    const profilePic = await sock.profilePictureUrl(participantString, 'image');
                    if (profilePic) {
                        profilePicUrl = profilePic;
                    }
                } catch (profileError) {
                    console.log('Could not fetch profile picture, using default');
                }
                
                // Construct API URL for welcome image
                const apiUrl = `https://api.some-random-api.com/welcome/img/2/gaming3?type=join&textcolor=green&username=${encodeURIComponent(displayName)}&guildName=${encodeURIComponent(groupName)}&memberCount=${groupMetadata.participants.length}&avatar=${encodeURIComponent(profilePicUrl)}`;
                
                // Fetch the welcome image
                const response = await fetch(apiUrl);
                if (response.ok) {
                    const imageBuffer = await response.buffer();
                    
                    // Send welcome image with caption (custom or default message)
                    await sock.sendMessage(id, {
                        image: imageBuffer,
                        caption: finalMessage,
                        mentions: [participantString],
                        ...channelInfo
                    });
                    continue; // Skip to next participant
                }
            } catch (imageError) {
                console.log('Image generation failed, falling back to text');
            }
            
            // Send text message (either custom message or fallback)
            await sock.sendMessage(id, {
                text: finalMessage,
                mentions: [participantString],
                ...channelInfo
            });
        } catch (error) {
            console.error('Error sending welcome message:', error);
            // Fallback to text message
            const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
            const user = participantString.split('@')[0];
            
            // Use custom message if available, otherwise use simple fallback
            let fallbackMessage;
            if (customMessage) {
                fallbackMessage = customMessage
                    .replace(/{user}/g, `@${user}`)
                    .replace(/{group}/g, groupName)
                    .replace(/{description}/g, groupDesc);
            } else {
                fallbackMessage = `Welcome @${user} to ${groupName}! 🎉`;
            }
            
            await sock.sendMessage(id, {
                text: fallbackMessage,
                mentions: [participantString],
                ...channelInfo
            });
        }
    }
}

module.exports = { welcomeCommand, handleJoinEvent };
const { handleWelcome } = require('../lib/welcome');
const { isWelcomeOn, getWelcome } = require('../lib/index');
const { channelInfo } = require('../lib/messageConfig');
const fetch = require('node-fetch');

async function welcomeCommand(sock, chatId, message, match) {
    // Check if it's a group
    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { text: 'This command can only be used in groups.' });
        return;
    }

    // Extract match from message
    const text = message.message?.conversation || 
                message.message?.extendedTextMessage?.text || '';
    const matchText = text.split(' ').slice(1).join(' ');

    await handleWelcome(sock, chatId, message, matchText);
}

async function handleJoinEvent(sock, id, participants) {
    // Check if welcome is enabled for this group
    const isWelcomeEnabled = await isWelcomeOn(id);
    if (!isWelcomeEnabled) return;

    // Get custom welcome message
    const customMessage = await getWelcome(id);

    // Get group metadata
    const groupMetadata = await sock.groupMetadata(id);
    const groupName = groupMetadata.subject;
    const groupDesc = groupMetadata.desc || 'No description available';

    // Send welcome message for each new participant
    for (const participant of participants) {
        try {
            // Handle case where participant might be an object or not a string
            const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
            const user = participantString.split('@')[0];
            
            // Get user's display name
            let displayName = user; // Default to phone number
            try {
                const contact = await sock.getBusinessProfile(participantString);
                if (contact && contact.name) {
                    displayName = contact.name;
                } else {
                    // Try to get from group participants
                    const groupParticipants = groupMetadata.participants;
                    const userParticipant = groupParticipants.find(p => p.id === participantString);
                    if (userParticipant && userParticipant.name) {
                        displayName = userParticipant.name;
                    }
                }
            } catch (nameError) {
                console.log('Could not fetch display name, using phone number');
            }
            
            // Process custom message with variables
            let finalMessage;
            if (customMessage) {
                finalMessage = customMessage
                    .replace(/{user}/g, `@${displayName}`)
                    .replace(/{group}/g, groupName)
                    .replace(/{description}/g, groupDesc);
            } else {
                // Default message if no custom message is set
                const now = new Date();
                const timeString = now.toLocaleString('en-US', {
                    month: '2-digit',
                    day: '2-digit', 
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true
                });
                
                finalMessage = `╭╼━≪•𝙽𝙴𝚆 𝙼𝙴𝙼𝙱𝙴𝚁•≫━╾╮\n┃𝚆𝙴𝙻𝙲𝙾𝙼𝙴: @${displayName} 👋\n┃Member count: #${groupMetadata.participants.length}\n┃𝚃𝙸𝙼𝙴: ${timeString}⏰\n╰━━━━━━━━━━━━━━━╯\n\n*@${displayName}* Welcome to *${groupName}*! 🎉\n*Group 𝙳𝙴𝚂𝙲𝚁𝙸𝙿𝚃𝙸𝙾𝙽*\n${groupDesc}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ Knight Bot*`;
            }
            
            // Try to send with image first (always try images)
            try {
                // Get user profile picture
                let profilePicUrl = `https://img.pyrocdn.com/dbKUgahg.png`; // Default avatar
                try {
                    const profilePic = await sock.profilePictureUrl(participantString, 'image');
                    if (profilePic) {
                        profilePicUrl = profilePic;
                    }
                } catch (profileError) {
                    console.log('Could not fetch profile picture, using default');
                }
                
                // Construct API URL for welcome image
                const apiUrl = `https://api.some-random-api.com/welcome/img/2/gaming3?type=join&textcolor=green&username=${encodeURIComponent(displayName)}&guildName=${encodeURIComponent(groupName)}&memberCount=${groupMetadata.participants.length}&avatar=${encodeURIComponent(profilePicUrl)}`;
                
                // Fetch the welcome image
                const response = await fetch(apiUrl);
                if (response.ok) {
                    const imageBuffer = await response.buffer();
                    
                    // Send welcome image with caption (custom or default message)
                    await sock.sendMessage(id, {
                        image: imageBuffer,
                        caption: finalMessage,
                        mentions: [participantString],
                        ...channelInfo
                    });
                    continue; // Skip to next participant
                }
            } catch (imageError) {
                console.log('Image generation failed, falling back to text');
            }
            
            // Send text message (either custom message or fallback)
            await sock.sendMessage(id, {
                text: finalMessage,
                mentions: [participantString],
                ...channelInfo
            });
        } catch (error) {
            console.error('Error sending welcome message:', error);
            // Fallback to text message
            const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
            const user = participantString.split('@')[0];
            
            // Use custom message if available, otherwise use simple fallback
            let fallbackMessage;
            if (customMessage) {
                fallbackMessage = customMessage
                    .replace(/{user}/g, `@${user}`)
                    .replace(/{group}/g, groupName)
                    .replace(/{description}/g, groupDesc);
            } else {
                fallbackMessage = `Welcome @${user} to ${groupName}! 🎉`;
            }
            
            await sock.sendMessage(id, {
                text: fallbackMessage,
                mentions: [participantString],
                ...channelInfo
            });
        }
    }
}

module.exports = { welcomeCommand, handleJoinEvent };
const { handleWelcome } = require('../lib/welcome');
const { isWelcomeOn, getWelcome } = require('../lib/index');
const { channelInfo } = require('../lib/messageConfig');
const fetch = require('node-fetch');

async function welcomeCommand(sock, chatId, message, match) {
    // Check if it's a group
    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { text: 'This command can only be used in groups.' });
        return;
    }

    // Extract match from message
    const text = message.message?.conversation || 
                message.message?.extendedTextMessage?.text || '';
    const matchText = text.split(' ').slice(1).join(' ');

    await handleWelcome(sock, chatId, message, matchText);
}

async function handleJoinEvent(sock, id, participants) {
    // Check if welcome is enabled for this group
    const isWelcomeEnabled = await isWelcomeOn(id);
    if (!isWelcomeEnabled) return;

    // Get custom welcome message
    const customMessage = await getWelcome(id);

    // Get group metadata
    const groupMetadata = await sock.groupMetadata(id);
    const groupName = groupMetadata.subject;
    const groupDesc = groupMetadata.desc || 'No description available';

    // Send welcome message for each new participant
    for (const participant of participants) {
        try {
            // Handle case where participant might be an object or not a string
            const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
            const user = participantString.split('@')[0];
            
            // Get user's display name
            let displayName = user; // Default to phone number
            try {
                const contact = await sock.getBusinessProfile(participantString);
                if (contact && contact.name) {
                    displayName = contact.name;
                } else {
                    // Try to get from group participants
                    const groupParticipants = groupMetadata.participants;
                    const userParticipant = groupParticipants.find(p => p.id === participantString);
                    if (userParticipant && userParticipant.name) {
                        displayName = userParticipant.name;
                    }
                }
            } catch (nameError) {
                console.log('Could not fetch display name, using phone number');
            }
            
            // Process custom message with variables
            let finalMessage;
            if (customMessage) {
                finalMessage = customMessage
                    .replace(/{user}/g, `@${displayName}`)
                    .replace(/{group}/g, groupName)
                    .replace(/{description}/g, groupDesc);
            } else {
                // Default message if no custom message is set
                const now = new Date();
                const timeString = now.toLocaleString('en-US', {
                    month: '2-digit',
                    day: '2-digit', 
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true
                });
                
                finalMessage = `╭╼━≪•𝙽𝙴𝚆 𝙼𝙴𝙼𝙱𝙴𝚁•≫━╾╮\n┃𝚆𝙴𝙻𝙲𝙾𝙼𝙴: @${displayName} 👋\n┃Member count: #${groupMetadata.participants.length}\n┃𝚃𝙸𝙼𝙴: ${timeString}⏰\n╰━━━━━━━━━━━━━━━╯\n\n*@${displayName}* Welcome to *${groupName}*! 🎉\n*Group 𝙳𝙴𝚂𝙲𝚁𝙸𝙿𝚃𝙸𝙾𝙽*\n${groupDesc}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ Knight Bot*`;
            }
            
            // Try to send with image first (always try images)
            try {
                // Get user profile picture
                let profilePicUrl = `https://img.pyrocdn.com/dbKUgahg.png`; // Default avatar
                try {
                    const profilePic = await sock.profilePictureUrl(participantString, 'image');
                    if (profilePic) {
                        profilePicUrl = profilePic;
                    }
                } catch (profileError) {
                    console.log('Could not fetch profile picture, using default');
                }
                
                // Construct API URL for welcome image
                const apiUrl = `https://api.some-random-api.com/welcome/img/2/gaming3?type=join&textcolor=green&username=${encodeURIComponent(displayName)}&guildName=${encodeURIComponent(groupName)}&memberCount=${groupMetadata.participants.length}&avatar=${encodeURIComponent(profilePicUrl)}`;
                
                // Fetch the welcome image
                const response = await fetch(apiUrl);
                if (response.ok) {
                    const imageBuffer = await response.buffer();
                    
                    // Send welcome image with caption (custom or default message)
                    await sock.sendMessage(id, {
                        image: imageBuffer,
                        caption: finalMessage,
                        mentions: [participantString],
                        ...channelInfo
                    });
                    continue; // Skip to next participant
                }
            } catch (imageError) {
                console.log('Image generation failed, falling back to text');
            }
            
            // Send text message (either custom message or fallback)
            await sock.sendMessage(id, {
                text: finalMessage,
                mentions: [participantString],
                ...channelInfo
            });
        } catch (error) {
            console.error('Error sending welcome message:', error);
            // Fallback to text message
            const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
            const user = participantString.split('@')[0];
            
            // Use custom message if available, otherwise use simple fallback
            let fallbackMessage;
            if (customMessage) {
                fallbackMessage = customMessage
                    .replace(/{user}/g, `@${user}`)
                    .replace(/{group}/g, groupName)
                    .replace(/{description}/g, groupDesc);
            } else {
                fallbackMessage = `Welcome @${user} to ${groupName}! 🎉`;
            }
            
            await sock.sendMessage(id, {
                text: fallbackMessage,
                mentions: [participantString],
                ...channelInfo
            });
        }
    }
}

module.exports = { welcomeCommand, handleJoinEvent };

*/




const _0xc9cfaf=_0x4a19;(function(_0x573ae2,_0x1957c0){const _0x212910={_0x2b1cea:0x189,_0x8c1936:0x165,_0x3951f1:0x1c3,_0x2d43dd:0x16f,_0x2f6c87:0x182,_0x2cb062:0x1f7,_0xf382df:0x1bc,_0x503fdd:0x237},_0x1001b2=_0x4a19,_0x18151e=_0x573ae2();while(!![]){try{const _0x3be3c2=parseInt(_0x1001b2(0x1a5))/(-0x147c+0xae2*-0x1+0x1f5f*0x1)*(-parseInt(_0x1001b2(_0x212910._0x2b1cea))/(0xc69+0x8*-0x31+-0xadf))+parseInt(_0x1001b2(_0x212910._0x8c1936))/(-0x95b+0xa76+-0x118)+-parseInt(_0x1001b2(_0x212910._0x3951f1))/(-0x279*-0xd+-0x6ca*-0x4+-0x3*0x13c3)+-parseInt(_0x1001b2(0x20f))/(0x1e3f+-0x1633+-0x807)*(parseInt(_0x1001b2(_0x212910._0x2d43dd))/(-0xee+-0x1*-0x1163+-0x106f*0x1))+-parseInt(_0x1001b2(_0x212910._0x2f6c87))/(-0x93b*0x2+-0xc87+0x1f04)*(-parseInt(_0x1001b2(_0x212910._0x2cb062))/(-0xf4+0x5e3+0x5*-0xfb))+parseInt(_0x1001b2(_0x212910._0xf382df))/(0x1409*-0x1+0x1*-0x1578+0x14c5*0x2)+-parseInt(_0x1001b2(_0x212910._0x503fdd))/(0x101d+-0x502+-0xb11)*(-parseInt(_0x1001b2(0x178))/(0x1bfc+0x1*0x31d+-0xa5a*0x3));if(_0x3be3c2===_0x1957c0)break;else _0x18151e['push'](_0x18151e['shift']());}catch(_0x3da2b8){_0x18151e['push'](_0x18151e['shift']());}}}(_0x1831,-0x3255*-0x6d+-0x4da25+0xa0a9*-0x8));const settings=require(_0xc9cfaf(0x1bf)+'\x73'),fs=require('\x66\x73'),path=require(_0xc9cfaf(0x1b4)),axios=require(_0xc9cfaf(0x15a));function _0x1831(){const _0x1f989b=['\x74\x65\x78\x74','\x20\x2e\x73\x6f\x72\x61\x20\x3c\x70\x72','\x62\x6f\x74\x4e\x61\x6d\x65','\x3c\x6f\x6e\x2f\x6f\x66\x66\x3e\x0a\x20','\x61\x63\x74\x0a\x20\x2d\x20\x2e\x77\x65','\x3e\x0a\x20\x2d\x20\x2e\x67\x6f\x6f\x64','\x6f\x72\x65\x61\x0a\x20\x2d\x20\x2e\x68','\x74\x63\x6f\x6d\x6d\x65\x6e\x74\x0a\x20','\x79\x3e\x0a\x20\x2d\x20\x2e\x6e\x65\x77','\x2d\x69\x6d\x67\x3e\x0a\x0a\ud83d\udd12\x20\x4f','\x6c\x65\x0a\x20\x2d\x20\x2e\x6c\x67\x62','\x6d\x65\x20\x3c\x6f\x6e\x2f\x6f\x66\x66','\x74\x65\x20\x40\x75\x73\x65\x72\x0a\x20','\x0a\x20\x2d\x20\x2e\x77\x61\x72\x6e\x20','\x6b\x20\x3c\x74\x65\x78\x74\x3e\x0a\x20','\x6b\x65\x72\x3a\x0a\x20\x2d\x20\x2e\x6d','\u2593\u2593\u2593\u2593\u2593\u2593\u2593\u2593\u2593\u2593','\ud83d\udce1\x20\x44\x65\x70\x6c\x6f\x79\x69\x6e','\x67\x6e\x61\x6d\x65\x20\x3c\x6e\x61\x6d','\x66\x6f\x72\x77\x61\x72\x64\x69\x6e\x67','\x69\x6a\x61\x62\x0a\x0a\ud83c\udfae\x20\x47\x61','\x53\x63\x6f\x72\x65','\x2e\x61\x6e\x73\x77\x65\x72\x20\x3c\x61','\x35\x33\x36\x38\x30\x4a\x56\x5a\x4a\x42\x76','\x75\x6e\x3a\x0a\x20\x2d\x20\x2e\x63\x6f','\x0a\x0a\ud83d\udd24\x20\x54\x65\x78\x74\x6d\x61','\x67\x73\x74\x69\x63\x6b\x65\x72\x20\x3c','\x65\x74\x61\x6c\x6c\x69\x63\x20\x3c\x74','\x75\x0a\x20\x2d\x20\x2e\x70\x69\x6e\x67','\x3c\x72\x65\x70\x6c\x79\x2d\x69\x6d\x67','\x75\x73\x65\x72\x0a\x20\x2d\x20\x2e\x69','\x6b\x65\x79','\x77\x65\x65\x74\x0a\x20\x2d\x20\x2e\x79','\x3c\x72\x65\x70\x6c\x79\x2d\x6d\x73\x67','\x20\x2d\x20\x2e\x63\x68\x61\x72\x61\x63','\x6e\x73\x77\x65\x72\x3e\x0a\x20\x2d\x20','\x77\x6e\x65\x72\x20\x43\x6f\x6d\x6d\x61','\x65\x64\x69\x74','\x61\x78\x69\x6f\x73','\x65\x6d\x69\x6e\x69\x0a\x20\x2d\x20\x2e','\x65\x64\x0a\x0a\ud83d\uddbc\ufe0f\x20\x41\x6e\x69\x6d','\x66\x3e\x0a\x20\x2d\x20\x2e\x61\x75\x74','\x20\x3c\x74\x65\x78\x74\x3e\x0a\x20\x2d','\x74\x0a\x20\x2d\x20\x2e\x73\x68\x61\x79','\x72\x0a\x20\x2d\x20\x2e\x66\x6c\x69\x72','\x2d\x20\x2e\x74\x61\x67\x61\x6c\x6c\x0a','\u2591\u2591\u2591\x5d\x20\ud83e\udde0','\x66\x3e\x0a\x20\x2d\x20\x2e\x73\x65\x74','\x74\x3e\x0a\x20\x2d\x20\x2e\x73\x65\x74','\x31\x32\x33\x38\x38\x34\x34\x43\x46\x6b\x58\x7a\x77','\x73\x0a\x20\x2d\x20\x2e\x61\x74\x74\x70','\x65\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x73','\x79\x74\x6d\x70\x34\x20\x3c\x6c\x69\x6e','\x20\x2e\x70\x6c\x61\x79\x20\x3c\x73\x6f','\x6e\x2f\x6f\x66\x66\x3e\x0a\x20\x2d\x20','\x74\x3a\x20','\x69\x6d\x61\x67\x65','\x72\x72\x65\x64\x20\x77\x68\x69\x6c\x65','\x75\x67\x0a\x20\x2d\x20\x2e\x77\x69\x6e','\x38\x37\x30\x4d\x6a\x6c\x76\x64\x71','\x49\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x73','\x73\x6f\x6e\x67\x3e\x0a\x20\x2d\x20\x2e','\x65\x72\x72\x6f\x72\x20\x6f\x63\x63\x75','\x6b\x0a\x20\x2d\x20\x2e\x66\x61\x63\x65','\x43\x6f\x6d\x6d\x61\x6e\x64\x73\x3a\x0a','\x20\x2d\x20\x2e\x73\x6e\x6f\x77\x20\x3c','\x0a\x20\x2d\x20\x2e\x70\x6f\x6b\x65\x0a','\x65\x78\x74\x3e\x0a\x20\x2d\x20\x2e\x69','\x33\x38\x31\x37\x6c\x78\x46\x61\x79\x72','\x6e\x20\x3c\x74\x65\x78\x74\x3e\x0a\x20','\u2591\x5d\x20\u26ab','\x0a\x20\x2d\x20\x2e\x31\x39\x31\x37\x20','\x72\x65\x61\x64\x46\x69\x6c\x65\x53\x79','\x67\x20\x76\x69\x73\x75\x61\x6c\x20\x55','\x20\x3c\x70\x72\x6f\x6d\x70\x74\x3e\x0a','\x3e\x0a\x20\x2d\x20\x2e\x6d\x65\x6e\x74','\x20\x2e\x62\x6c\x61\x63\x6b\x70\x69\x6e','\x75\x6e\x64\x65\x72\x20\x3c\x74\x65\x78','\x32\x35\x35\x32\x33\x37\x35\x45\x70\x54\x63\x4d\x73','\x40\x75\x73\x65\x72\x0a\x20\x2d\x20\x2e','\x71\x75\x6f\x74\x65\x64','\x6a\x70\x67','\x20\x2e\x72\x6f\x73\x65\x64\x61\x79\x0a','\x6e\x2e\x6d\x70\x33','\x2e\x6b\x69\x63\x6b\x20\x40\x75\x73\x65','\x33\x31\x31\x30\x39\x30\x75\x56\x44\x74\x79\x77','\u2593\u2591\u2591\u2591\u2591\u2591\u2591\x5d\x20\ud83d\udd04','\x2d\x20\x2e\x61\x6e\x74\x69\x62\x61\x64','\x67\x20\x79\x6f\x75\x72\x20\x72\x65\x71','\x6e\x67\x20\x70\x75\x6c\x73\x65\x20\x73','\x72\x0a\x20\x2d\x20\x2e\x77\x61\x72\x6e','\x20\x70\x72\x6f\x63\x65\x73\x73\x69\x6e','\x5b\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591','\x2d\x20\x2e\x63\x6f\x6d\x72\x61\x64\x65','\x63\x2f\x70\x72\x69\x76\x61\x74\x65\x3e','\x65\x3e\x0a\x20\x2d\x20\x2e\x73\x65\x74','\x76\x65\x62\x67\x0a\x20\x2d\x20\x2e\x72','\x48\x65\x6c\x70\x20\x43\x6f\x6d\x6d\x61','\x20\x3c\x6f\x6e\x2f\x6f\x66\x66\x2f\x73','\x74\x0a\x20\x2d\x20\x2e\x68\x6f\x72\x6e','\x6c\x6f\x61\x64\x65\x72\x3a\x0a\x20\x2d','\x61\x70\x61\x6e\x0a\x20\x2d\x20\x2e\x6b','\x0a\x20\x2d\x20\x2e\x66\x61\x63\x65\x62','\x69\x6e\x75\x74\x65\x73\x3e\x0a\x20\x2d','\x61\x75\x64\x69\x6f','\x61\x74\x72\x69\x78\x20\x5b\u2593\u2593\u2593','\x3c\x71\x3e\x0a\x20\x2d\x20\x2e\x67\x65','\x20\x2d\x20\x2e\x63\x72\x79\x0a\x20\x2d','\x73\x67\x3e\x0a\x20\x2d\x20\x2e\x63\x68','\x69\x6e\x67\x73\x20\x40\x75\x73\x65\x72','\x73\x0a\x20\x2d\x20\x2e\x76\x76\x0a\x20','\x6c\x20\x6c\x69\x6e\x6b\x20\x5b\u2593\u2593','\x2e\x73\x68\x69\x70\x20\x40\x75\x73\x65','\x34\x42\x64\x54\x79\x73\x67','\x2e\x73\x65\x74\x74\x69\x6e\x67\x73\x0a','\x63\x72\x6f\x70\x0a\x20\x2d\x20\x2e\x74','\x67\x64\x65\x73\x63\x20\x3c\x74\x65\x78','\x65\x73\x69\x61\x0a\x20\x2d\x20\x2e\x6a','\x2e\x64\x61\x72\x65\x0a\x0a\ud83e\udd16\x20\x41','\x31\ufe0f\u20e3','\x74\x61\x74\x75\x73\x3e\x0a\x20\x2d\x20','\x6f\x6d\x70\x74\x3e\x0a\x0a\ud83c\udfaf\x20\x46','\x2d\x20\x2e\x74\x72\x69\x67\x67\x65\x72','\x74\x3e\x0a\x20\x2d\x20\x2e\x6e\x65\x6f','\x0a\x2a\x4b\x49\x4e\x47\x20\x42\x41\x4c','\x6d\x65\x6d\x65\x0a\x20\x2d\x20\x2e\x74','\x72\x0a\x20\x2d\x20\x2e\x73\x69\x6d\x70','\x6e\x64\x20\x45\x72\x72\x6f\x72\x3a','\x70\x61\x74\x68','\x2e\x2e\x2f\x61\x73\x73\x65\x74\x73\x2f','\x0a\x20\x2d\x20\x2e\x74\x74\x73\x20\x3c','\x61\x6b\x65\x20\x3c\x70\x61\x63\x6b\x6e','\x61\x72\x64\x0a\x20\x2d\x20\x2e\x6f\x6f','\x73\x65\x72\x0a\x20\x2d\x20\x2e\x70\x72','\x0a\x20\x2d\x20\x2e\x63\x6c\x65\x61\x72','\ud83d\udce1\x20\x45\x73\x74\x61\x62\x6c\x69\x73','\x34\x39\x30\x33\x38\x30\x33\x7a\x44\x44\x6c\x59\x72','\ud83d\udce1\x20\x43\x59\x42\x45\x52\x57\x45\u039e','\x0a\x20\x2d\x20\x2e\x69\x6e\x64\x6f\x6e','\x2e\x2e\x2f\x73\x65\x74\x74\x69\x6e\x67','\x70\x75\x72\x70\x6c\x65\x20\x3c\x74\x65','\x6d\x70\x6c\x69\x6d\x65\x6e\x74\x20\x40','\x6a\x6f\x69\x6e','\x35\x35\x37\x31\x33\x36\x38\x4a\x47\x51\x6c\x49\x65','\x6f\x6f\x6b\x20\x3c\x6c\x69\x6e\x6b\x3e','\x20\x2e\x6d\x61\x74\x72\x69\x78\x20\x3c','\x61\x6d\x65\x3e\x0a\x20\x2d\x20\x2e\x65','\x66\x3e\x0a\x0a\ud83c\udfa8\x20\x49\x6d\x61\x67','\x6e\x73\x75\x6c\x74\x20\x40\x75\x73\x65','\x73\x65\x6e\x64\x4d\x65\x73\x73\x61\x67','\x0a\x20\x2d\x20\x2e\x67\x61\x79\x0a\x20','\x69\x6e\x6b\x3e\x0a\x20\x2d\x20\x2e\x6a','\x6c\x65\x61\x72\x0a\x20\x2d\x20\x2e\x74','\x61\x6e\x74\x69\x6c\x69\x6e\x6b\x0a\x20','\x20\x2d\x20\x2e\x61\x6e\x74\x69\x74\x61','\x20\x2d\x20\x2e\x69\x6e\x73\x74\x61\x67','\x74\x65\x72\x20\x40\x75\x73\x65\x72\x0a','\x6d\x69\x6d\x65\x74\x79\x70\x65','\x70\x72\x6f\x6d\x70\x74\x3e\x0a\x20\x2d','\x6f\x77\x6e\x65\x72\x0a\x20\x2d\x20\x2e','\x2d\x20\x2e\x6d\x75\x74\x65\x20\x3c\x6d','\x70\x74\x74','\x63\x6f\x6e\x74\x65\x78\x74\x49\x6e\x66','\x68\x69\x6e\x67\x20\x6e\x65\x75\x72\x61','\x3a\x0a\x0a\ud83c\udf10\x20\x47\x65\x6e\x65\x72','\x2e\x73\x74\x75\x70\x69\x64\x20\x40\x75','\x69\x6e\x67\x20\x3c\x6f\x6e\x2f\x6f\x66','\x65\x78\x74\x3e\x0a\x20\x2d\x20\x2e\x73','\x0a\x0a\x41\x76\x61\x69\x6c\x61\x62\x6c','\x68\x69\x64\x65\x74\x61\x67\x20\x3c\x6d','\x3a\x0a\x20\x2d\x20\x2e\x70\x69\x65\x73','\x2d\x20\x2e\x67\x6c\x69\x74\x63\x68\x20','\x0a\x20\x2d\x20\x2e\x73\x74\x61\x66\x66','\x73\x3a\x0a\x20\x2d\x20\x2e\x6d\x65\x6e','\x38\x62\x61\x6c\x6c\x20\x3c\x71\x75\x65','\x65\x78\x69\x73\x74\x73\x53\x79\x6e\x63','\x6c\x69\x6e\x6b\x3e\x0a\x20\x2d\x20\x2e','\x70\x61\x6c\x6d\x0a','\ud83d\udce1\x20\x46\x69\x6e\x61\x6c\x69\x7a\x69','\ud83d\udd25\x0a\x20\x2d\x20\x2e\x69\x67\x73\x20','\x72\x65\x61\x63\x74\x20\x3c\x6f\x6e\x2f','\x61\x72\x69\x0a\x20\x2d\x20\x2e\x67\x6f','\x62\x6f\x74\x5f\x69\x6d\x61\x67\x65\x2e','\x0a\x20\x2d\x20\x2e\x63\x68\x69\x6e\x61','\x20\x40\x75\x73\x65\x72\x0a\x20\x2d\x20','\x6f\x66\x66\x3e\x0a\x20\x2d\x20\x2e\x61','\x69\x64\x0a\x20\x2d\x20\x2e\x75\x72\x6c','\x63\x61\x70\x74\x69\x6f\x6e','\x6f\x6d\x6f\x74\x65\x20\x40\x75\x73\x65','\x5d\x20\u2705','\x3c\x74\x65\x78\x74\x3e\x0a\x20\x2d\x20','\x6f\x72\x65\x61\x64\x20\x3c\x6f\x6e\x2f','\x6e\x67\x3e\x0a\x20\x2d\x20\x2e\x73\x6f','\x2f\x20\x2e\x64\x65\x6c\x0a\x20\x2d\x20','\x2e\x61\x72\x65\x6e\x61\x20\x3c\x74\x65','\x38\x54\x71\x45\x50\x6c\x6f','\x0a\x3e\x20\x4f\x77\x6e\x65\x72\x3a\x20','\x3a\x0a\x20\x2d\x20\x2e\x67\x70\x74\x20','\x61\x72\x74\x6d\x70\x0a\x20\x2d\x20\x2e','\x75\x74\x6f\x73\x74\x61\x74\x75\x73\x20','\x2e\x70\x61\x74\x0a\x20\x2d\x20\x2e\x68','\x63\x6b\x65\x72\x20\x3c\x74\x65\x78\x74','\x0a\x20\x2d\x20\x2e\x61\x64\x6d\x69\x6e','\x74\x65\x0a\x20\x2d\x20\x2e\x63\x6c\x65','\x2d\x20\x2e\x64\x65\x6c\x65\x74\x65\x20','\x61\x6c\x20\x43\x6f\x6d\x6d\x61\x6e\x64','\x79\x20\x3c\x71\x75\x65\x72\x79\x3e\x0a','\x72\x61\x6d\x20\x3c\x6c\x69\x6e\x6b\x3e','\x62\x6f\x74\x4f\x77\x6e\x65\x72','\x0a\x20\x2d\x20\x2e\x61\x6c\x69\x76\x65','\u2593\u2593\u2593\u2591\u2591\x5d\x20\ud83d\udcab','\x20\x2d\x20\x2e\x62\x6c\x75\x72\x0a\x20','\x61\x75\x64\x69\x6f\x2f\x6d\x70\x65\x67','\x78\x74\x3e\x0a\x20\x2d\x20\x2e\x74\x68','\x57\x65\x65\x62\x20\x43\x6f\x72\x65\x20','\x75\x65\x73\x74\x2e','\x3e\x0a\x20\x2d\x20\x2e\x61\x75\x74\x6f','\x2d\x20\x2e\x67\x6c\x61\x73\x73\x0a\x20','\x2d\x20\x2e\x61\x75\x74\x6f\x74\x79\x70','\x31\x34\x32\x33\x30\x44\x76\x6d\x6f\x6e\x55','\x75\x70\x64\x61\x74\x65\x0a\x20\x2d\x20','\x3a\x0a\x20\x2d\x20\x2e\x68\x65\x61\x72','\x2d\x20\x2e\x6a\x61\x69\x6c\x0a\x20\x2d','\x2d\x20\x2e\x73\x69\x6d\x61\x67\x65\x0a','\x20\x3c\x63\x6f\x75\x6e\x74\x72\x79\x3e','\x67\x70\x70\x20\x3c\x72\x65\x70\x6c\x79','\x7a\x69\x6e\x67\x20\x43\x79\x62\x65\x72','\x61\x74\x62\x6f\x74\x0a\x20\x2d\x20\x2e','\x74\x74\x65\x72\x3e\x0a\x20\x2d\x20\x2e','\x74\x65\x78\x74\x3e\x0a\x20\x2d\x20\x2e','\x67\x20\x3c\x6f\x6e\x2f\x6f\x66\x66\x3e','\x65\x3a\x0a\x20\x2d\x20\x2e\x6e\x6f\x6d','\x79\x0a\x20\x2d\x20\x2e\x63\x69\x72\x63','\x61\x6e\x67\x6d\x61\x6e\x0a\x20\x2d\x20','\x20\x2e\x6b\x69\x73\x73\x0a\x20\x2d\x20','\x42\x20\x4f\x4e\x4c\x49\x4e\x45\x20\x5b'];_0x1831=function(){return _0x1f989b;};return _0x1831();}function _0x4a19(_0x1f8ec0,_0x3ffd3f){const _0x26e6bc=_0x1831();return _0x4a19=function(_0x31e5ee,_0x10067f){_0x31e5ee=_0x31e5ee-(-0xa78+-0x15c8*0x1+0x2194);let _0x4b2034=_0x26e6bc[_0x31e5ee];return _0x4b2034;},_0x4a19(_0x1f8ec0,_0x3ffd3f);}async function helpCommand(_0x304b99,_0x2fe19e,_0x17bf8b){const _0x1e7fc3={_0x3e544b:0x1ab,_0x10f79c:0x1f8,_0xfc7bfb:0x204,_0x32a8a7:0x1dc,_0x1e5997:0x167,_0x22567c:0x1e1,_0x1af343:0x205,_0x118765:0x1b6,_0x153e30:0x219,_0x12274c:0x224,_0x26fb97:0x1e0,_0x47d8bc:0x1a2,_0x463ee6:0x1cb,_0x1bbab9:0x1ee,_0xebec37:0x1b9,_0x273ec3:0x1f0,_0x2780ae:0x22c,_0x355126:0x188,_0x58061d:0x1a1,_0x11638d:0x22d,_0x5ee839:0x1cd,_0x23f36f:0x1cc,_0x2ecad5:0x1dd,_0x546475:0x21a,_0x4d89bd:0x225,_0x18f6d6:0x1a8,_0x4e5f0b:0x164,_0x435be7:0x232,_0x4c2e4e:0x193,_0x41d05a:0x192,_0x4816b3:0x1ba,_0x47d5f8:0x1ff,_0xdb71d9:0x23d,_0x54ece1:0x1e8,_0xc6fe62:0x1ed,_0x21e0a9:0x20e,_0x4c0d18:0x1f3,_0x33666d:0x1ed,_0xb590ca:0x16a,_0x23bcc2:0x196,_0x1c11f2:0x155,_0x502c94:0x17f,_0x2ea4d3:0x174,_0x468b5e:0x15b,_0x3a2924:0x1a7,_0x3b4f15:0x1b1,_0x230836:0x1b7,_0x278147:0x1c6,_0x4a9d89:0x1e7,_0x5c8c73:0x1de,_0x22927b:0x1be,_0x5ea2d3:0x226,_0x22ec3d:0x234,_0x35b263:0x218,_0x495d81:0x1aa,_0x520691:0x170,_0x5a580a:0x19e,_0x38da84:0x23e,_0x1a2e08:0x15f,_0x51ac20:0x186,_0x49ca73:0x156,_0x26b2fd:0x1a4,_0xd2be33:0x239,_0x246a4d:0x23b,_0x5c1d35:0x15e,_0x1decf9:0x1c5,_0x548264:0x179,_0x1d92d2:0x1c0,_0x3841b9:0x209,_0x572de4:0x1f6,_0x11447b:0x180,_0x360527:0x198,_0x3acd5a:0x169,_0x1bea81:0x1cf,_0x5ea07e:0x203,_0xa9cda9:0x19a,_0x10469d:0x1c4,_0xaed7e5:0x168,_0x376858:0x22a,_0x4d012e:0x154,_0x8dafa6:0x191,_0x20cc80:0x1ca,_0x4ef128:0x20d,_0x499ffa:0x212,_0x57d733:0x1ae,_0x773f28:0x15c,_0x3062c8:0x21b,_0x3f700a:0x1fc,_0x1f6bf1:0x173,_0x529609:0x216,_0x1b2fd5:0x190,_0x1299e5:0x1c9,_0x4058d5:0x19d,_0x32bd6e:0x18a,_0x31c512:0x231,_0x593899:0x17d,_0x50fd9a:0x1e6,_0x4944c0:0x1bd,_0x5a089c:0x1f1,_0xa41d40:0x220,_0x521c75:0x159,_0x153642:0x1c2,_0x118aa6:0x185,_0x301bc4:0x17c,_0x18109b:0x233,_0x41cc66:0x235,_0x5441e5:0x16c,_0x4b6564:0x1ef,_0x2a87c8:0x1d6,_0x5023fd:0x19c,_0x42fd68:0x1c9,_0x4f0371:0x195,_0x22a38c:0x172},_0x12656d=_0xc9cfaf,_0x2dbda0=_0x12656d(0x1b0)+'\x44\x57\x49\x4e\x2a\x0a\x3e\x20\x42\x6f'+_0x12656d(0x16b)+(settings[_0x12656d(0x222)]||'\x62\x61\x6c\x64\x77\x69\x6e\x2d\x4d\x44')+('\x0a\x3e\x20\x56\x65\x72\x73\x69\x6f\x6e'+'\x3a\x20')+(settings['\x76\x65\x72\x73\x69\x6f\x6e']||_0x12656d(_0x1e7fc3._0x3e544b))+_0x12656d(_0x1e7fc3._0x10f79c)+(settings[_0x12656d(_0x1e7fc3._0xfc7bfb)]||'\x64\x61\x76\x65')+(_0x12656d(_0x1e7fc3._0x32a8a7)+_0x12656d(_0x1e7fc3._0x1e5997)+_0x12656d(0x1d8)+_0x12656d(0x201)+_0x12656d(_0x1e7fc3._0x22567c)+_0x12656d(0x23c)+_0x12656d(_0x1e7fc3._0x1af343)+_0x12656d(_0x1e7fc3._0x118765)+_0x12656d(_0x1e7fc3._0x153e30)+_0x12656d(0x1d3)+'\x6a\x6f\x6b\x65\x0a\x20\x2d\x20\x2e\x71'+'\x75\x6f\x74\x65\x0a\x20\x2d\x20\x2e\x66'+_0x12656d(_0x1e7fc3._0x12274c)+'\x61\x74\x68\x65\x72\x20\x3c\x63\x69\x74'+_0x12656d(0x228)+_0x12656d(0x166)+'\x20\x3c\x74\x65\x78\x74\x3e\x0a\x20\x2d'+'\x20\x2e\x6c\x79\x72\x69\x63\x73\x20\x3c'+_0x12656d(0x171)+_0x12656d(0x1e2)+'\x73\x74\x69\x6f\x6e\x3e\x0a\x20\x2d\x20'+'\x2e\x67\x72\x6f\x75\x70\x69\x6e\x66\x6f'+_0x12656d(_0x1e7fc3._0x26fb97)+_0x12656d(0x1fe)+_0x12656d(_0x1e7fc3._0x47d8bc)+'\x2d\x20\x2e\x74\x72\x74\x20\x3c\x74\x65'+'\x78\x74\x3e\x20\x3c\x6c\x61\x6e\x67\x3e'+'\x0a\x20\x2d\x20\x2e\x73\x73\x20\x3c\x6c'+_0x12656d(_0x1e7fc3._0x463ee6)+_0x12656d(_0x1e7fc3._0x1bbab9)+'\x0a\x0a\ud83d\udc6e\u200d\u2642\ufe0f\x20\x41\x64\x6d\x69\x6e\x20'+_0x12656d(0x174)+'\x20\x2d\x20\x2e\x62\x61\x6e\x20\x40\x75'+_0x12656d(_0x1e7fc3._0xebec37)+_0x12656d(_0x1e7fc3._0x273ec3)+'\x72\x0a\x20\x2d\x20\x2e\x64\x65\x6d\x6f'+_0x12656d(_0x1e7fc3._0x2780ae)+_0x12656d(0x1d4)+_0x12656d(0x19b)+'\x20\x2e\x75\x6e\x6d\x75\x74\x65\x0a\x20'+_0x12656d(0x200)+_0x12656d(0x1f5)+_0x12656d(_0x1e7fc3._0x355126)+_0x12656d(0x18e)+_0x12656d(_0x1e7fc3._0x58061d)+_0x12656d(_0x1e7fc3._0x11638d)+_0x12656d(0x183)+_0x12656d(_0x1e7fc3._0x5ee839)+_0x12656d(0x18b)+'\x77\x6f\x72\x64\x0a\x20\x2d\x20\x2e\x63'+_0x12656d(_0x1e7fc3._0x23f36f)+'\x61\x67\x20\x3c\x6d\x73\x67\x3e\x0a\x20'+_0x12656d(0x161)+'\x20\x2d\x20\x2e\x74\x61\x67\x6e\x6f\x74'+'\x61\x64\x6d\x69\x6e\x0a\x20\x2d\x20\x2e'+_0x12656d(_0x1e7fc3._0x2ecad5)+_0x12656d(0x1a0)+_0x12656d(0x217)+'\x72\x65\x73\x65\x74\x6c\x69\x6e\x6b\x0a'+_0x12656d(0x1ce)+_0x12656d(_0x1e7fc3._0x546475)+'\x0a\x20\x2d\x20\x2e\x77\x65\x6c\x63\x6f'+_0x12656d(0x22b)+_0x12656d(_0x1e7fc3._0x4d89bd)+'\x62\x79\x65\x20\x3c\x6f\x6e\x2f\x6f\x66'+_0x12656d(0x163)+_0x12656d(_0x1e7fc3._0x18f6d6)+_0x12656d(_0x1e7fc3._0x4e5f0b)+_0x12656d(_0x1e7fc3._0x435be7)+_0x12656d(_0x1e7fc3._0x4c2e4e)+_0x12656d(0x215)+_0x12656d(0x229)+_0x12656d(0x158)+'\x6e\x64\x73\x3a\x0a\x20\x2d\x20\x2e\x6d'+'\x6f\x64\x65\x20\x3c\x70\x75\x62\x6c\x69'+_0x12656d(_0x1e7fc3._0x41d05a)+_0x12656d(_0x1e7fc3._0x4816b3)+'\x73\x65\x73\x73\x69\x6f\x6e\x0a\x20\x2d'+'\x20\x2e\x61\x6e\x74\x69\x64\x65\x6c\x65'+_0x12656d(_0x1e7fc3._0x47d5f8)+_0x12656d(0x1fa)+_0x12656d(0x210)+_0x12656d(0x1a6)+'\x20\x2d\x20\x2e\x73\x65\x74\x70\x70\x20'+_0x12656d(_0x1e7fc3._0xdb71d9)+_0x12656d(0x20c)+_0x12656d(_0x1e7fc3._0x54ece1)+_0x12656d(_0x1e7fc3._0xc6fe62)+_0x12656d(0x1fb)+_0x12656d(0x223)+_0x12656d(_0x1e7fc3._0x21e0a9)+_0x12656d(0x1da)+_0x12656d(0x15d)+_0x12656d(_0x1e7fc3._0x4c0d18)+_0x12656d(_0x1e7fc3._0x33666d)+'\x6e\x74\x69\x63\x61\x6c\x6c\x20\x3c\x6f'+_0x12656d(_0x1e7fc3._0xb590ca)+'\x2e\x70\x6d\x62\x6c\x6f\x63\x6b\x65\x72'+_0x12656d(_0x1e7fc3._0x23bcc2)+_0x12656d(0x1ac)+('\x2e\x70\x6d\x62\x6c\x6f\x63\x6b\x65\x72'+'\x20\x73\x65\x74\x6d\x73\x67\x20\x3c\x74'+_0x12656d(0x1db)+'\x65\x74\x6d\x65\x6e\x74\x69\x6f\x6e\x20'+_0x12656d(_0x1e7fc3._0x1c11f2)+_0x12656d(_0x1e7fc3._0x502c94)+'\x69\x6f\x6e\x20\x3c\x6f\x6e\x2f\x6f\x66'+_0x12656d(0x1c7)+'\x65\x2f\x53\x74\x69\x63\x6b\x65\x72\x20'+_0x12656d(_0x1e7fc3._0x2ea4d3)+_0x12656d(0x207)+_0x12656d(0x213)+'\x20\x2d\x20\x2e\x73\x74\x69\x63\x6b\x65'+'\x72\x0a\x20\x2d\x20\x2e\x72\x65\x6d\x6f'+_0x12656d(0x194)+_0x12656d(_0x1e7fc3._0x468b5e)+_0x12656d(_0x1e7fc3._0x3a2924)+_0x12656d(0x23a)+_0x12656d(0x1e4)+_0x12656d(_0x1e7fc3._0x3b4f15)+_0x12656d(_0x1e7fc3._0x230836)+_0x12656d(_0x1e7fc3._0x278147)+'\x6d\x6f\x6a\x69\x6d\x69\x78\x20\ud83d\ude00\x2b'+_0x12656d(_0x1e7fc3._0x4a9d89)+'\x3c\x6c\x69\x6e\x6b\x3e\x0a\x20\x2d\x20'+'\x2e\x69\x67\x73\x63\x20\x3c\x6c\x69\x6e'+'\x6b\x3e\x0a\x0a\ud83d\uddbc\ufe0f\x20\x50\x69\x65\x73'+_0x12656d(_0x1e7fc3._0x5c8c73)+_0x12656d(0x214)+_0x12656d(0x1eb)+_0x12656d(_0x1e7fc3._0x22927b)+_0x12656d(0x1a9)+_0x12656d(0x199)+_0x12656d(_0x1e7fc3._0x5ea2d3)+_0x12656d(_0x1e7fc3._0x22ec3d)+'\x6d\x65\x73\x3a\x0a\x20\x2d\x20\x2e\x74'+'\x69\x63\x74\x61\x63\x74\x6f\x65\x20\x40'+'\x75\x73\x65\x72\x0a\x20\x2d\x20\x2e\x68'+_0x12656d(0x21d)+'\x2e\x67\x75\x65\x73\x73\x20\x3c\x6c\x65'+_0x12656d(_0x1e7fc3._0x35b263)+'\x74\x72\x69\x76\x69\x61\x0a\x20\x2d\x20'+_0x12656d(0x236)+_0x12656d(0x157)+'\x2e\x74\x72\x75\x74\x68\x0a\x20\x2d\x20'+_0x12656d(_0x1e7fc3._0x495d81)+_0x12656d(_0x1e7fc3._0x520691)+_0x12656d(0x1f9)+_0x12656d(_0x1e7fc3._0x5a580a)+'\x6d\x69\x6e\x69\x20\x3c\x71\x3e\x0a\x20'+'\x2d\x20\x2e\x69\x6d\x61\x67\x69\x6e\x65'+_0x12656d(0x17e)+'\x20\x2d\x20\x2e\x66\x6c\x75\x78\x20\x3c'+_0x12656d(0x1d2)+_0x12656d(0x221)+_0x12656d(0x1ad)+_0x12656d(0x238)+_0x12656d(0x1c1)+_0x12656d(_0x1e7fc3._0x38da84)+_0x12656d(0x1c8)+_0x12656d(0x160)+_0x12656d(_0x1e7fc3._0x1a2e08)+_0x12656d(0x1e9)+'\x6f\x64\x6e\x69\x67\x68\x74\x0a\x20\x2d'+_0x12656d(_0x1e7fc3._0x51ac20)+_0x12656d(_0x1e7fc3._0x49ca73)+_0x12656d(0x1d0)+'\x20\x2d\x20\x2e\x77\x61\x73\x74\x65\x64'+_0x12656d(0x1ec)+_0x12656d(_0x1e7fc3._0x26b2fd)+_0x12656d(0x1b2)+_0x12656d(0x1ec)+_0x12656d(0x1d9)+'\x73\x65\x72\x20\x3c\x74\x65\x78\x74\x3e'+_0x12656d(_0x1e7fc3._0xd2be33)+_0x12656d(0x22f)+_0x12656d(_0x1e7fc3._0x246a4d)+_0x12656d(0x177)+'\x63\x65\x20\x3c\x74\x65\x78\x74\x3e\x0a'+_0x12656d(0x175)+_0x12656d(0x219)+'\x69\x6d\x70\x72\x65\x73\x73\x69\x76\x65'+_0x12656d(_0x1e7fc3._0x5c1d35)+_0x12656d(_0x1e7fc3._0x1decf9)+_0x12656d(0x219)+'\x6c\x69\x67\x68\x74\x20\x3c\x74\x65\x78'+_0x12656d(0x1af)+_0x12656d(_0x1e7fc3._0x548264)+'\x2d\x20\x2e\x64\x65\x76\x69\x6c\x20\x3c'+_0x12656d(_0x1e7fc3._0x153e30)+_0x12656d(_0x1e7fc3._0x1d92d2)+_0x12656d(_0x1e7fc3._0x3841b9)+_0x12656d(0x181)+'\x74\x3e\x0a\x20\x2d\x20\x2e\x6c\x65\x61'+'\x76\x65\x73\x20\x3c\x74\x65\x78\x74\x3e'+_0x12656d(0x17b)+'\x3c\x74\x65\x78\x74\x3e\x0a\x20\x2d\x20'+_0x12656d(_0x1e7fc3._0x572de4)+'\x78\x74\x3e\x0a\x20\x2d\x20\x2e\x68\x61'+_0x12656d(0x1fd))+('\x3e\x0a\x20\x2d\x20\x2e\x73\x61\x6e\x64'+'\x20\x3c\x74\x65\x78\x74\x3e\x0a\x20\x2d'+_0x12656d(_0x1e7fc3._0x11447b)+_0x12656d(0x22e)+_0x12656d(0x1df)+_0x12656d(0x1f2)+'\x2e\x66\x69\x72\x65\x20\x3c\x74\x65\x78'+'\x74\x3e\x0a\x0a\ud83d\udce5\x20\x44\x6f\x77\x6e'+_0x12656d(_0x1e7fc3._0x360527)+_0x12656d(_0x1e7fc3._0x3acd5a)+_0x12656d(0x1f4)+'\x6e\x67\x20\x3c\x73\x6f\x6e\x67\x3e\x0a'+'\x20\x2d\x20\x2e\x73\x70\x6f\x74\x69\x66'+_0x12656d(0x202)+_0x12656d(_0x1e7fc3._0x1bea81)+_0x12656d(_0x1e7fc3._0x5ea07e)+_0x12656d(_0x1e7fc3._0xa9cda9)+_0x12656d(_0x1e7fc3._0x10469d)+'\x0a\x20\x2d\x20\x2e\x74\x69\x6b\x74\x6f'+'\x6b\x20\x3c\x6c\x69\x6e\x6b\x3e\x0a\x20'+'\x2d\x20\x2e\x76\x69\x64\x65\x6f\x20\x3c'+'\x73\x6f\x6e\x67\x3e\x0a\x20\x2d\x20\x2e'+_0x12656d(_0x1e7fc3._0xaed7e5)+'\x6b\x3e\x0a\x0a\ud83e\udde9\x20\x4d\x69\x73\x63'+_0x12656d(0x211)+_0x12656d(0x197)+_0x12656d(0x21c)+_0x12656d(_0x1e7fc3._0x376858)+'\x74\x0a\x20\x2d\x20\x2e\x6c\x6f\x6c\x69'+'\x63\x65\x0a\x20\x2d\x20\x2e\x69\x74\x73'+'\x2d\x73\x6f\x2d\x73\x74\x75\x70\x69\x64'+'\x0a\x20\x2d\x20\x2e\x6e\x61\x6d\x65\x63'+_0x12656d(0x1b8)+'\x67\x77\x61\x79\x0a\x20\x2d\x20\x2e\x74'+_0x12656d(_0x1e7fc3._0x4d012e)+_0x12656d(0x227)+_0x12656d(_0x1e7fc3._0x8dafa6)+_0x12656d(_0x1e7fc3._0x20cc80)+_0x12656d(_0x1e7fc3._0x4ef128)+_0x12656d(_0x1e7fc3._0x499ffa)+'\x20\x2e\x70\x61\x73\x73\x65\x64\x0a\x20'+_0x12656d(_0x1e7fc3._0x57d733)+_0x12656d(_0x1e7fc3._0x773f28)+_0x12656d(_0x1e7fc3._0x3062c8)+_0x12656d(0x176)+_0x12656d(0x19f)+_0x12656d(0x21e)+_0x12656d(_0x1e7fc3._0x3f700a)+_0x12656d(0x16e)+_0x12656d(_0x1e7fc3._0x1f6bf1)+_0x12656d(0x1e5)));try{const _0x302e9b={};_0x302e9b['\x74\x65\x78\x74']='\ud83d\udce1\x20\x49\x6e\x69\x74\x69\x61\x6c\x69'+_0x12656d(_0x1e7fc3._0x529609)+_0x12656d(0x20a)+_0x12656d(_0x1e7fc3._0x1b2fd5)+_0x12656d(0x17a);const _0x435994={};_0x435994['\x71\x75\x6f\x74\x65\x64']=_0x17bf8b;let _0x3ee65b=await _0x304b99[_0x12656d(_0x1e7fc3._0x1299e5)+'\x65'](_0x2fe19e,_0x302e9b,_0x435994);const _0x3fad5b=[_0x12656d(0x1bb)+_0x12656d(0x1d7)+_0x12656d(0x1a3)+'\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\x5d\x20'+'\u2699\ufe0f','\ud83d\udce1\x20\x48\x61\x63\x6b\x69\x6e\x67\x20'+'\x74\x69\x6d\x65\x66\x6c\x6f\x77\x20\x6d'+_0x12656d(_0x1e7fc3._0x4058d5)+_0x12656d(_0x1e7fc3._0x32bd6e),_0x12656d(_0x1e7fc3._0x31c512)+_0x12656d(_0x1e7fc3._0x593899)+'\x49\x20\x5b\u2593\u2593\u2593\u2593\u2593\u2593\u2591'+_0x12656d(0x162),_0x12656d(_0x1e7fc3._0x50fd9a)+_0x12656d(0x18d)+'\x79\x6e\x63\x20\x5b\u2593\u2593\u2593\u2593\u2593'+_0x12656d(0x206),_0x12656d(_0x1e7fc3._0x4944c0)+_0x12656d(0x21f)+_0x12656d(0x230)+_0x12656d(_0x1e7fc3._0x5a089c)];for(const _0xa63f61 of _0x3fad5b){await new Promise(_0x54c947=>setTimeout(_0x54c947,-0x21b1+0x1*-0x1749+0x13*0x31a));const _0x201ad1={};_0x201ad1[_0x12656d(_0x1e7fc3._0xa41d40)]=_0xa63f61,_0x201ad1[_0x12656d(_0x1e7fc3._0x521c75)]=_0x3ee65b[_0x12656d(0x23f)],await _0x304b99['\x73\x65\x6e\x64\x4d\x65\x73\x73\x61\x67'+'\x65'](_0x2fe19e,_0x201ad1);}const _0x2b5f15=path[_0x12656d(_0x1e7fc3._0x153642)](__dirname,_0x12656d(0x1b5)+_0x12656d(0x1ea)+_0x12656d(_0x1e7fc3._0x118aa6));if(fs[_0x12656d(0x1e3)](_0x2b5f15)){const _0xc36f3b=fs[_0x12656d(_0x1e7fc3._0x301bc4)+'\x6e\x63'](_0x2b5f15),_0x3c026a={};_0x3c026a[_0x12656d(_0x1e7fc3._0x18109b)+_0x12656d(_0x1e7fc3._0x41cc66)]=0x1,_0x3c026a['\x69\x73\x46\x6f\x72\x77\x61\x72\x64\x65'+'\x64']=!![];const _0x56a15a={};_0x56a15a[_0x12656d(_0x1e7fc3._0x5441e5)]=_0xc36f3b,_0x56a15a[_0x12656d(_0x1e7fc3._0x4b6564)]=_0x2dbda0,_0x56a15a[_0x12656d(_0x1e7fc3._0x2a87c8)+'\x6f']=_0x3c026a;const _0x101ec9={};_0x101ec9[_0x12656d(0x184)]=_0x17bf8b,await _0x304b99[_0x12656d(0x1c9)+'\x65'](_0x2fe19e,_0x56a15a,_0x101ec9);const _0x1cb6ca=path[_0x12656d(0x1c2)](__dirname,_0x12656d(0x1b5)+'\x62\x6f\x74\x5f\x62\x61\x6c\x64\x77\x69'+_0x12656d(0x187));if(fs['\x65\x78\x69\x73\x74\x73\x53\x79\x6e\x63'](_0x1cb6ca)){const _0x41069f=fs[_0x12656d(_0x1e7fc3._0x301bc4)+'\x6e\x63'](_0x1cb6ca),_0x1cf533={};_0x1cf533[_0x12656d(_0x1e7fc3._0x5023fd)]=_0x41069f,_0x1cf533[_0x12656d(0x1d1)]=_0x12656d(0x208),_0x1cf533[_0x12656d(0x1d5)]=!![];const _0x32f16e={};_0x32f16e[_0x12656d(0x184)]=_0x17bf8b,await _0x304b99[_0x12656d(0x1c9)+'\x65'](_0x2fe19e,_0x1cf533,_0x32f16e);}}else{const _0x1af8e0={};_0x1af8e0[_0x12656d(0x220)]=_0x2dbda0;const _0x5a021e={};_0x5a021e[_0x12656d(0x184)]=_0x17bf8b,await _0x304b99[_0x12656d(_0x1e7fc3._0x42fd68)+'\x65'](_0x2fe19e,_0x1af8e0,_0x5a021e);}}catch(_0x4663ba){console['\x65\x72\x72\x6f\x72'](_0x12656d(_0x1e7fc3._0x4f0371)+_0x12656d(0x1b3),_0x4663ba);const _0x1ab1c7={};_0x1ab1c7[_0x12656d(_0x1e7fc3._0xa41d40)]='\x53\x6f\x72\x72\x79\x2c\x20\x61\x6e\x20'+_0x12656d(_0x1e7fc3._0x22a38c)+_0x12656d(0x16d)+_0x12656d(0x18f)+_0x12656d(0x18c)+_0x12656d(0x20b);const _0x51d44a={};_0x51d44a[_0x12656d(0x184)]=_0x17bf8b,await _0x304b99[_0x12656d(0x1c9)+'\x65'](_0x2fe19e,_0x1ab1c7,_0x51d44a);}}module['\x65\x78\x70\x6f\x72\x74\x73']=helpCommand;