const isAdmin = require('../lib/isAdmin');  // Admin checker

async function tagAllCommand(sock, chatId, senderId, message) {
    try {
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

        if (!isBotAdmin) {
            await sock.sendMessage(chatId, { text: '⚠️ The bot must be an admin first!' }, { quoted: message });
            return;
        }

        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { text: '❌ Only group admins can use this command.' }, { quoted: message });
            return;
        }

        // Get group metadata
        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants;

        if (!participants || participants.length === 0) {
            await sock.sendMessage(chatId, { text: '👀 No participants found in this kingdom.' });
            return;
        }

        // King Baldwin style message
        let messageText = `
👑⚜️ *KING BALDWIN SUMMONS ALL* ⚜️👑
━━━━━━━━━━━━━━━━━━━━━━
⚔️ *Behold the warriors of this realm:* ⚔️\n
`;

        participants.forEach(p => {
            const id = p.id.split('@')[0];
            // Extravagant double-tag effect
            messageText += `⚔️ @${id} ⚔️ @${id} ⚔️\n`;
        });

        messageText += '━━━━━━━━━━━━━━━━━━━━━━\n🛡️ *Long live King Baldwin!* 🛡️';

        // Send message with real mentions
        await sock.sendMessage(chatId, {
            text: messageText,
            mentions: participants.map(p => p.id)
        });

    } catch (error) {
        console.error('Error in tagall command:', error);
        await sock.sendMessage(chatId, { text: '❌ Failed to summon the warriors.' });
    }
}

module.exports = tagAllCommand;